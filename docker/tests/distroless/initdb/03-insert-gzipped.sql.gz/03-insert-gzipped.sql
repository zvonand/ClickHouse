INSERT INTO test_db.events (id, name) VALUES (3, 'gzipped');
